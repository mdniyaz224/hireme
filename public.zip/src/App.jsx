import Dashboard from "./Pages/Dashboard";
import Mainrouts from "./Routes/index";
const App = () => {
  return (
    <>
      <Mainrouts />
      {/* <Dashboard /> */}
    </>
  );
};

export default App;
