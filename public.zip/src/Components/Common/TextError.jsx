/* eslint-disable react/prop-types */

const TextError = (props) => {
  return <div className="error">{props.children}</div>;
};

export default TextError;
