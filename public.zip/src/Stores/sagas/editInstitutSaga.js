// editSaga.js
import { takeLatest, call, put } from 'redux-saga/effects';
import { editSuccess, editFailure } from '../toolkits/editInstitutSlice';
import { putRequest } from '../../Services/ApiService';


function* editData(action) {

  try {
    console.log("action", action);
    // `${ApiUrl.GetInstituteById}${id.payload}`
    // const response = yield call(putRequest, `institutes/edit/${action.payload.id}`, JSON.stringify(action.payload.data)); // Make the API call to update the data
    const response = yield call(putRequest, `institutes/edit/${action.payload.id}`, JSON.stringify(action.payload.formData)); // Make the API call to update the data
    if (response.status === 200) {
      yield put(editSuccess(response.data)); // Dispatch edit success action with the updated data
    } else {
      yield put(editFailure('Failed to edit data')); // Dispatch edit failure action with error message
    }
  } catch (error) {
    yield put(editFailure(error.message)); // Dispatch edit failure action with error message
  }
}

export function* watchEditData() {
  yield takeLatest('editInstitute/startEdit', editData);
}
