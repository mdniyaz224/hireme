// apiSaga.js
import { takeLatest, call, put } from 'redux-saga/effects';
import { fetchData, deleteDataSuccess, deleteDataFailure } from '../toolkits/displayInstituteSlice';
import { deleteRequest } from '../../Services/ApiService';

function* deleteAPIData(action) {
  try {
    const response = yield call(deleteRequest, "institutes/delete", action.payload); // Make the API call to delete the item
    if (response.status === 200) {
      yield put(deleteDataSuccess()); // Dispatch delete success action
      yield put(fetchData()); // Refresh the data after successful deletion
    } else {
      yield put(deleteDataFailure('Failed to delete item')); // Dispatch delete failure action with error message
    }
  } catch (error) {
    yield put(deleteDataFailure(error.message)); // Dispatch delete failure action with error message
  }
}

export function* watchDeleteData() {
  yield takeLatest('getInstitute/deleteData', deleteAPIData);
}
