// authSaga.js
import { takeLatest, call, put } from 'redux-saga/effects';
import { post } from "../../Services/ApiService"
import { resetStart,resetFailure } from '../toolkits/resetSlice';


function* resets(action) {
    console.log(action)
    try {
        yield put(resetStart()); // Set loading state

        yield call(post, `users/reset-password`, action.payload); // Make the API call

        // yield put(resetSuccess(user)); // Dispatch success action with user data
    } catch (error) {
        yield put(resetFailure(error.message)); // Dispatch failure action with error message
    }
}

export function* watchReset() {
    // alert("------------")
    yield takeLatest('reset/resetSuccess', resets); // Replace 'auth/login' with your actual login action type
    console.log("abc----------")
}
