import { Bar } from "react-chartjs-2";
import { Chart as ChartJS } from "chart.js/auto";
import { MUIBox, MUIGrid, MUITypography } from "../Components/MUI-Component";
import { Pie } from "react-chartjs-2";
import { Card } from "@mui/material";
// import { Card } from '@mui/material';
const BarChart = () => {
  const data = {
    labels: ["January", "February", "March", "April", "May", "June"],
    datasets: [
      {
        label: "Sales",
        backgroundColor: "rgba(75,192,192,0.4)",
        borderColor: "rgba(75,192,192,1)",
        borderWidth: 1,
        hoverBackgroundColor: "rgba(75,192,192,0.8)",
        hoverBorderColor: "rgba(75,192,192,1)",
        data: [65, 59, 80, 81, 56, 55],
      },
    ],
  };
  // ----------------------------------------
  const data1 = {
    labels: ["Category 1", "Category 2", "Category 3"],
    datasets: [
      {
        data: [100, 200, 300],
        backgroundColor: ["#0088FE", "#00C49F", "#FFBB28"],
      },
    ],
  };

  // -----------------------------------------
  return (
    <MUIBox sx={{ marginLeft: "20%" }} className="dashboar-head-box">
      <MUIGrid container>
        <MUIGrid item>
          <Card></Card>
        </MUIGrid>
        <MUIGrid item>

        </MUIGrid>
        <MUIGrid item>

        </MUIGrid>
        <MUIGrid item>
          
        </MUIGrid>
      </MUIGrid>

      <Bar data={data} className="pai-chart" />

      <Pie data={data1} className="pai-chart" />
    </MUIBox>
  );
};

export default BarChart;
