
import { MUIBox, MUITypography } from '../Components/MUI-Component'

const Walk_in = () => {
  return (
    <>
    
    <MUIBox sx={{textAlign:'center',marginTop:'15%',color:'red'}}>
        <MUITypography varient="h4">
            404| page not found
        </MUITypography>
    </MUIBox>
    </>
  )
}

export default Walk_in