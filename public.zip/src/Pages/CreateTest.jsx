// import { Formik, FieldArray, Form } from "formik";
// import * as Yup from "yup";
// import FormikControl from "../Components/Common/FormikControl";
// import {
//   MUIBox,
//   MUIButton,
//   MUIGrid,
//   MUITypography,
// } from "../Components/MUI-Component/index";

// const validationSchema = Yup.object().shape({
//   newform: Yup.array().of(
//     Yup.object().shape({
//       technical: Yup.string().required("Select Category Type"),
//       cplue: Yup.string().required("Select Test Type"),
//       cpluesnumber: Yup.string().required("Number of Questions is required"),
//       cpluslavel: Yup.string().required("Select Level"),
//       java: Yup.string().required("Select Test Type"),
//       javanumber: Yup.string().required("Number of Questions is required"),
//       javanumberlevel: Yup.string().required("Select Level"),
//     })
//   ),
// });

// const CreateTest = () => {
//   const colleges = [
//     { key: "select an option", value: "" },
//     { key: "LPU", value: "LPU" },
//     { key: "CU", value: "CU" },
//     { key: "DU", value: "DU" },
//     { key: "AMU", value: "AMU" },
//   ];

//   const initialFormValues = {
//     technical: "",
//     cplue: "",
//     cpluesnumber: "",
//     cpluslavel: "",
//     java: "",
//     javanumber: "",
//     javanumberlevel: "",
//   };

//   const handleSubmit = (values, { resetForm }) => {
//     console.log(values);
//     resetForm();
//   };

//   return (
//     <Formik
//       initialValues={{ newform: [initialFormValues] }}
//       validationSchema={validationSchema}
//       onSubmit={handleSubmit}
//       enableReinitialize={true}
//     >
//       {({ values }) => (
//         <MUIBox className="add-form-container">
//           <MUITypography variant="h6" sx={{ marginTop: "-20px" }}>
//             Institutes
//           </MUITypography>
//           <MUIBox className="bg-white head-form-box mb-2">
//             <MUITypography variant="body1" className="test-body-text">
//               Institutes &gt; Assign Test &gt; Create Test
//             </MUITypography>
//           </MUIBox>
//           <Form>
//             <FieldArray name="newform">
//               {({ push, remove }) => (
//                 <MUIBox className="bg-color test-form-containers">
//                   {values.newform.map((form, index) => (
//                     <MUIBox key={index}>
//                       <MUIGrid
//                         container
//                         className="form-grid-container"
//                         spacing={5}
//                       >
//                         <MUIGrid item>
//                           <FormikControl
//                             name={`newform[${index}].technical`}
//                             label="Select Category Type"
//                             className="test-add-form-control tech-width"
//                             control="select"
//                             options={colleges}
//                           />
//                         </MUIGrid>
//                       </MUIGrid>
//                       <MUIGrid
//                         container
//                         className="form-grid-container"
//                         spacing={5}
//                       >
//                         <MUIGrid item xs={12} sm={4}>
//                           <FormikControl
//                             name={`newform[${index}].cplue`}
//                             placeholder="Cplue"
//                             className="test-add-form-control t-width"
//                             label="Select Test Type"
//                             control="select"
//                             options={colleges}
//                           />
//                         </MUIGrid>
//                         <MUIGrid item xs={12} sm={4}>
//                           <FormikControl
//                             name={`newform[${index}].cpluesnumber`}
//                             placeholder="Cplues Number"
//                             type="number"
//                             className="test-add-form-control t-width"
//                             control="input"
//                             label="Number of Questions"
//                           />
//                         </MUIGrid>
//                         <MUIGrid item xs={12} sm={4}>
//                           <FormikControl
//                             name={`newform[${index}].cpluslavel`}
//                             placeholder="Cplus Level"
//                             control="select"
//                             label="Select Level"
//                             className="test-add-form-control t-width"
//                             options={colleges}
//                           />
//                         </MUIGrid>
//                       </MUIGrid>
//                       <MUIGrid
//                         container
//                         className="form-grid-container"
//                         spacing={5}
//                       >
//                         <MUIGrid item xs={12} sm={4}>
//                           <FormikControl
//                             name={`newform[${index}].java`}
//                             label="Select Test Type"
//                             control="select"
//                             className="test-add-form-control t-width"
//                             options={colleges}
//                           />
//                         </MUIGrid>
//                         <MUIGrid item xs={12} sm={4}>
//                           <FormikControl
//                             name={`newform[${index}].javanumber`}
//                             placeholder="Java Number"
//                             control="input"
//                             type="number"
//                             className="test-add-form-control t-width"
//                             label="Number of Questions"
//                           />
//                         </MUIGrid>
//                         <MUIGrid item xs={12} sm={4}>
//                           <FormikControl
//                             name={`newform[${index}].javanumberlevel`}
//                             placeholder="Java Number Level"
//                             control="select"
//                             label="Select Level"
//                             className="test-add-form-control t-width"
//                             options={colleges}
//                           />
//                         </MUIGrid>
//                       </MUIGrid>
//                       {index > 0 && (
//                         <button type="button"
//                          onClick={() => remove(index)}
//                          >
//                           -
//                         </button>
//                       )}
//                     </MUIBox>
//                   ))}
//                   <MUIButton
//                     type="button"
//                     onClick={() => push({ ...initialFormValues })}
//                   >
//                     Add Test Type
//                   </MUIButton>
//                 </MUIBox>
//               )}
//             </FieldArray>
//             <MUIButton type="submit" style={{ marginLeft: "20%" }}>
//               Submit
//             </MUIButton>
//           </Form>
//         </MUIBox>
//       )}
//     </Formik>
//   );
// };

// export default CreateTest;

// ----------------------------------------------------------------------------------






// export default CreateTest;



// ----------------------------------------------------







// ----------------------------------------==============




import { Formik, FieldArray, Form } from 'formik';
import * as Yup from 'yup';

import FormikControl from "../Components/Common/FormikControl";
import  {AddIcon} from '../Icons/index';
import {
    MUIBox,
    MUIButton,
    MUIGrid,
    MUITypography,
} from "../Components/MUI-Component";

const validationSchema = Yup.object().shape({
  testValue: Yup.array().of(
    Yup.object().shape({
      test_category: Yup.string().required('Test category is required'),
      test_time: Yup.number()
        .min(0, 'Invalid Time')
        .required('Time is required'),
      testTypeCatagory: Yup.array().of(
        Yup.object().shape({
          test_type: Yup.string().required('Test type is required'),
          no_of_question: Yup.number()
            .typeError('Number of questions must be a valid number')
            .integer('Number of questions must be an integer')
            .min(1, 'Number of questions must be at least 1')
            .required('Number of questions is required'),
          test_level: Yup.string().required('Test level is required'),
        })
      ),
    })
  ),
});

const CreateTest = () => {
  const test_category = [
    { key: 'Technical', value: 'Technical' },
    { key: 'apptitude', value: 'Apptitude' },
  ];

  const test_type = [
    { key: 'C++', value: 'C++' },
    { key: 'Java', value: 'Java' },
    { key: 'CSS', value: 'CSS' },
  ];
  const test_level = [
    { key: 'Hard', value: 'Hard' },
    { key: 'Medium', value: 'Medium' },
    { key: 'Easy', value: 'Easy' },
  ];

  const initialValues = {
    testValue: [
      {
        test_category: '',
        test_time: null,
        testTypeCatagory: [
          {
            test_type: '',
            no_of_question: '',
            test_level: '',
          },
        ],
      },
    ],
  };

  const onSubmit = (values) => {
    console.log(values);
  };

  return (
    <Formik
      initialValues={initialValues}
      enableReinitialize={true}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
    >
      {() => {
        return (
          <MUIBox className="add-form-container">
            <MUIBox>
              <MUITypography variant="h6" sx={{ marginTop: "-40px" }}>Institutes</MUITypography>
              <MUIBox className="bg-white head-form-box mb-2">
             <MUITypography variant="body1" className="test-body-text">Institutes &gt; Assign Test &gt; Create Test</MUITypography>   
              </MUIBox>
            </MUIBox>
            <MUITypography sx={{textAlign:'right',paddingTop:'10px',marginRight:'18px',color:'green'}}>Duration of Test-60 mins</MUITypography>
            <Form autoComplete="off">
              <>
                <FieldArray name="testValue">
                  {(fieldArrayProps) => {
                    const { form, push } = fieldArrayProps;
                    const { values } = form;
                    const { testValue } = values;

                    return (
                      <>
                        {testValue.map((item, index) => (
                          <MUIGrid container key={index} className="bg-color test-form-containers">
                            <MUIGrid container  className="form-grid-container">
                              <MUIGrid item md={12} sm={12} xs={12}>
                                <MUITypography>
                                  Select Category Type
                                </MUITypography>
                                <FormikControl
                                  control="select"
                                  name={`testValue.${index}.test_category`}
                                  options={test_category}
                                  className="test-add-form-control tech-width"
                                />
                              </MUIGrid>
                            </MUIGrid>
                            {
                              <FieldArray
                                name={`testValue.${index}.testTypeCatagory`}
                              >
                                {(fieldArrayProps) => {
                                  const { push } = fieldArrayProps;
                                  const testType = item.testTypeCatagory;
                                  return (
                                    <>
                                      {testType.map(
                                        (value, innerIndex) => (
                                          <MUIGrid
                                            container
                                            key={innerIndex}
                                          >
                                            <MUIGrid item md sm={12} xs={12}>
                                              <MUITypography>
                                                Select Test Type
                                              </MUITypography>
                                              <FormikControl
                                                control="select"
                                                name={`testValue.${index}.testTypeCatagory.${innerIndex}.test_type`}
                                                options={test_type}
                                                className="test-add-form-control t-width"
                                              />
                                            </MUIGrid>
                                            <MUIGrid item md sm={12} xs={12}>
                                              <MUITypography>
                                                Number of Questions
                                              </MUITypography>
                                              <FormikControl
                                                className="test-add-form-control t-width"
                                                control="input"
                                                type="number"
                                                name={`testValue.${index}.testTypeCatagory.${innerIndex}.no_of_question`}
                                              />
                                            </MUIGrid>
                                            <MUIGrid item md sm={12} xs={12}>
                                              <MUITypography>
                                                Select Level
                                              </MUITypography>
                                              <FormikControl
                                                control="select"
                                                name={`testValue.${index}.testTypeCatagory.${innerIndex}.test_level`}
                                                options={test_level}
                                                className="test-add-form-control t-width"
                                              />
                                            </MUIGrid>
                                          </MUIGrid>
                                        )
                                      )}
                                      <MUIGrid container className="add-type-head">
                                        <MUIGrid item>
                                          <MUIButton
                                          sx={{marginTop:'-50px'}}
                                            startIcon={<AddIcon />}
                                            onClick={() =>
                                              push({
                                                test_type: '',
                                                no_of_question: '',
                                                test_level: '',
                                              })
                                            }
                                          >
                                             Add Test Type
                                            </MUIButton>
                                        </MUIGrid>
                                        <MUIGrid item className="time-allocated">
                                          <MUITypography>
                                            Time Alloted (mins)
                                          </MUITypography>
                                          &nbsp;
                                          <FormikControl
                                            control="input"
                                            type="number"
                                            name={`testValue.${index}.test_time`}
                                          />
                                        </MUIGrid>
                                      </MUIGrid>
                                    </>
                                  );
                                }}
                              </FieldArray>
                            }
                          </MUIGrid>
                        ))}
                        <MUIBox className="bg-white" sx={{marginTop:'15px',marginBottom:'15px',paddingTop:'10px',paddingBottom:'10px'}}>
                          <MUIButton
                            startIcon={<AddIcon />}
                            label="Select Another Category Type"
                            onClick={() =>
                              push({
                                test_category: '',
                                test_time: null,
                                testTypeCatagory: [
                                  {
                                    test_type: '',
                                    no_of_question: '',
                                    test_level: '',
                                  },
                                ],
                              })
                            }
                          >
                            Select Another Category Type
                            </MUIButton>
                        </MUIBox>
                      </>
                    );
                  }}
                </FieldArray>
                <MUIBox>
                  <MUIButton
                    label="Submit"
                    variant="contained"
                    type="submit"
                  >
                    submit
                  </MUIButton>
                  <MUIButton
                  sx={{marginLeft:'50px'}}
                    label="Cancel"
                    variant="outlined"
                    type="reset"
                  >
                    Cancel
                  </MUIButton>
                </MUIBox>
              </>
            </Form>
          </MUIBox>
        );
      }}
    </Formik>
  );
};

export default CreateTest;