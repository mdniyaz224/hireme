
import { MUIBox, MUITypography } from '../Components/MUI-Component'

const Question_bank = () => {
  return (
    <>
        <MUIBox sx={{textAlign:'center',marginTop:'15%',color:'red'}}>
        <MUITypography varient="h4">
            404| page not found
        </MUITypography>
    </MUIBox>
    </>
  )
}

export default Question_bank