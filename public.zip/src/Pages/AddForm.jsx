import CommonForm from "./CommonForm";
import { useState } from "react";
import { useDispatch } from "react-redux";
import { addInstuite } from "../Stores/toolkits/AddInstitutSlice";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import { useNavigate } from "react-router-dom";
const AddForm = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [optionSelected, setSelectedOption]=useState([])
  const [initialValues, setInitialValues] = useState({
    university: "lpu",
    institute: "lpu mca",
    tpo_name: "niyaz",
    tpo_email: "md@gmail.com",
    tpo_phone_number: "9523990312",
    qualification: optionSelected,
  });
  const handleInputChange = (name, value) => {
    console.log(value.props.value, "name and value");
    optionSelected.push(value.props.value)
    // console.log(optionSelected,"---------------->optionSelected")
  };
  const onSubmit = async (values, { resetForm }) => {
    console.log("values>>>>> ", values);
    const payload = {
      university: values.university,
      institute: values.institute,
      tpo_name: values.tpo_name,
      tpo_email: values.tpo_email,
      tpo_phone_number: values.tpo_phone_number,
      qualification: values.qualification,
    };
    dispatch(addInstuite(payload));
    // toast.success("institute addad  successfully");
    // console.log(addInstuite(payload), "payload");
    // setTimeout(function () {
    //   navigate("/institutes");
    // }, 1000);
  };
  return (
    <>
      <CommonForm
        lable="Submit"
        onSubmit={onSubmit}
        initialValues={initialValues}
        head="Add"
        onChange={handleInputChange}
      />
    </>
  );
};

export default AddForm;
