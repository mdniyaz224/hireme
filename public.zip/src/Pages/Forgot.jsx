import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Formik, Form } from "formik";
import * as Yup from "yup";
import Formikcontrol from "../Components/Common/FormikControl";
import {
  MUIBox,
  MUIButton,
  MUITypography,
} from "../Components/MUI-Component/index";
import { useDispatch, useSelector } from "react-redux";
import { forgotSuccess } from "../Stores/toolkits/forgotSlice";
import { emailRegex } from "../Regex";
import { Link ,useNavigate} from "react-router-dom";

const Forgot = () => {
  const navigate=useNavigate();
  const dispatch = useDispatch();
  const initialValues = {
    email: "amankukreti@yopmail.com",
  };

  const validationSchema = Yup.object({
    email: Yup.string()
      .email("Invalid email")
      .matches(emailRegex, "Invalid email")
      .required("Email is Required!"),
  });

  const onSubmit = async (values) => {
    // alert("---------")
    dispatch(forgotSuccess(values));
    toast.success("Login successfully");
    setTimeout(function(){
      navigate("/reset-password")
  }, 1000);
   
  };

  return (
    <>
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
    >
      {() => {
        return (
          <MUIBox className="form-container">
            <MUIBox className="form-header">
              <MUITypography variant="h5">Forget Password</MUITypography>
              <MUITypography variant="subtitle2">
                Please enter your registered e-mail to reset your password
              </MUITypography>
            </MUIBox>
            <Form>
              <Formikcontrol
                control="input"
                type="email"
                placeholder="Email"
                name="email"
                label="Enter your email address"
                className="form-control"
              />
              <MUIBox className="submitBtn">
                <MUIButton
                  type="submit"
                  variant="contained"
                  onSubmit={onSubmit}
                >
                  Submit
                </MUIButton>
              </MUIBox>
              <MUIBox className="page-redirect text-center">
                <Link to="/login">Back to login</Link>
              </MUIBox>
            </Form>
          </MUIBox>
        );
      }}
    </Formik>
    <ToastContainer />
    </>
  );
};

export default Forgot;
