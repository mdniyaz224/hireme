import CommonForm from "./CommonForm";
import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { startEdit } from "../Stores/toolkits/editInstitutSlice";
import { fetchData } from "../Stores/toolkits/getEditSlice";
import { useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";
import { toast } from "react-toastify";

const EditForm = () => {
  const params = useParams();
  const id = params.id;
  console.log(id, "idid---------------");
  const navigate = useNavigate();
  const dispatch = useDispatch();
  // const editId = useSelector(
  //   (state) => state.editInstituteRedcure.editInstitute.editid
  // );

  const getEditData = useSelector(
    (state) => state.getEditRedcure.getEditInstitute.data
  );
  console.log("aaaaaaaa", getEditData);
  let initialValues = {
    tpo_email: "",
    university: "",
    institute: "",
    tpo_name: "",
    tpo_phone_number: "",
    qualification: "",
  };
  useEffect(() => {
    dispatch(fetchData(id)); // Dispatch the fetchData action when the component mounts
  }, [dispatch]);
  if (getEditData) {
    initialValues = {
      tpo_email: getEditData.tpo_email,
      university: getEditData?.university?.value,
      institute: getEditData?.institute?.value,
      tpo_name: getEditData.tpo_name,
      tpo_phone_number: getEditData.tpo_phone_number,
      qualification: getEditData.qualification,
    };
  }
  console.log(getEditData.university, "-----------------");
  const onSubmit = async (values, { resetForm }) => {
    console.log("getEditData----------------------------- ", getEditData);
    const formData = {
      university: values.university.values,
      institute: values.institute,
      tpo_name: values.tpo_name,
      tpo_email: values.tpo_email,
      tpo_phone_number: values.tpo_phone_number,
      qualification: JSON.stringify(values.qualification),
    };
    dispatch(startEdit({ id, formData }));
    console.log(id, "------------id----------------");
    toast.success("institute addad  successfully");

    // setTimeout(function () {
    //   navigate("/institutes");
    // }, 1000);
    resetForm({ values: "" });
  };
  console.log(initialValues, "---------initial values");
  return (
    <>
      <CommonForm
        lable="Update"
        onSubmit={onSubmit}
        initialValues={initialValues}
        head="Edit"
      />
    </>
  );
};

export default EditForm;
