import { MUIBox, MUITypography } from "../Components/MUI-Component";

const Result = () => {
  return (
    <>
      <MUIBox sx={{ textAlign: "center", marginTop: "15%", color: "red" }}>
        <MUITypography varient="h4">404| page not found</MUITypography>
      </MUIBox>
    </>
  );
};

export default Result;
