const react_base_url = 'http://localhost:3051/v1';
export default react_base_url;